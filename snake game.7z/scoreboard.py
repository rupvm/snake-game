from turtle import Turtle

class scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.score=0
        self.color("white")
        self.hideturtle()
        self.penup()
        self.goto(x=0, y=260)
        self.Write()


    def Write(self):

        self.write(arg=f"score:{self.score}", align='center', font=("Courier", 20, "normal"))

    def game_over(self):
        self.goto(0, 0)
        self.write(arg="Game over",align='center',font=("Courier",17,"normal"))



    def update(self):
        self.score+=1
        self.clear()
        self.Write()
        print(self.score)



